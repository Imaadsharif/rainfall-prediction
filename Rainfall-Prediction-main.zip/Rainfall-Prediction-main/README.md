# Rainfall-Prediction
Here is an ML project to predict rainfall. The dataset that I have used is that of Chittagong. I have taken two ML models SVR and KNN,compared the 2 and found out that KNN fared better.  
