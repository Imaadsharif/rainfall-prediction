# Rainfall-prediction

Rainfall Prediction project: Displaying amount of rainfall in a particular state or region, well in advance using machine learning models. In this project I have used the SVR and KNN model which predicts the Rain fall using "Daily Rainfall dataset Chittagong.csv" dataset.
